
document.querySelectorAll('.image-box').forEach(box => {
    const images = box.querySelectorAll('.image-container img');
    const prevButton = box.querySelector('.prev');
    const nextButton = box.querySelector('.next');
    let index = 0;

    function showImage(idx) {
        images.forEach((img, i) => {
            img.style.transform = `translateX(-${idx * 100}%)`;
        });
    }

    prevButton.addEventListener('click', () => {
        index = (index - 1 + images.length) % images.length;
        showImage(index);
    });

    nextButton.addEventListener('click', () => {
        index = (index + 1) % images.length;
        showImage(index);
    });
});
